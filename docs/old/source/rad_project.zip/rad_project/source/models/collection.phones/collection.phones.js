RAD.model('collection.phones', Backbone.Collection.extend({

}), true);