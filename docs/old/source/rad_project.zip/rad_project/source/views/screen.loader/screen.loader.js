RAD.view("screen.loader", RAD.Blanks.View.extend({

    className: "screen",

    url: 'source/views/screen.loader/screen.loader.html'

}));