import {View, publish, template} from 'RAD.js';

class WelcomePage extends View {
    template = template('Hello, World!');
}

// place view to DOM container via navigator plugin
publish('navigation.show', {
    container: '#screen',
    content: WelcomePage
});