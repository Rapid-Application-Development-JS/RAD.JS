"use strict";
import {View, publish} from 'RAD.js';

class WelcomePage extends View {

    // view template
    template = require('./template.ejs');

    // events binding
    events = {
        'click button': 'click',
        'input input': 'nameChange'
    };

    // first type of working with DOM via props changing
    click() {
        let amount = this.props.get('amount');
        this.props.set('amount', amount + 1);
    }

    // second type of working with DOM via template data
    getTemplateData() {
        return {
            string: 'Hello, '
        }
    }

    // third type of working with DOM via references
    nameChange() {
        let name = this.refs.my_input.value;
        this.props.set('name', name);
    }
}

// place view to DOM container via navigator plugin
publish('navigation.show', {
    container: '#screen',
    content: WelcomePage,
    options: {
        amount: 0,
        name: 'World'
    }
});