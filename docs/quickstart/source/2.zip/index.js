import {View, publish} from 'RAD.js';

class WelcomePage extends View {

    // view template
    template = require('./template.ejs');

    // events binding
    events = {
        'click button': 'onClick',
        'input input': 'onInput'
    };

    // first type of working with DOM via props changing
    onClick() {
        let count = this.props.get('count');
        this.props.set('count', count + 1);
    }

    // second type of working with DOM via template data
    getTemplateData() {
        return {
            string: 'Hello, '
        }
    }

    // third type of working with DOM via references
    onInput() {
        let name = this.refs.my_input.value;
        this.props.set('name', name);
    }
}

// place view to DOM container via navigator plugin
publish('navigation.show', {
    container: '#screen',
    content: WelcomePage,
    options: {
        count: 0,
        name: 'World'
    }
});