import {View, publish, template} from 'RAD.js'

class WelcomePage extends View {
    template = template(`<div>
	    <h1><%= 'Hello ' + this.name + '!' %></h1>
	    <div>
	        <input type="text" value="<%= this.name %>"/>
	    </div>
	    <button>Clicks:<%= this.counter %></button>
	</div>`);

    events() {
        return {
            'click button': 'onClick',
            'input input': 'onInput'
        };
    }

    initialize(options) {
        this.counter = options.counter;
        this.name = options.name;
    }

    onClick() {
        this.counter += 1;
        this.render();
    }

    onInput(e) {
        this.name = e.target.value;
        this.render();
    }
}

new WelcomePage({
    el: '#screen',
    counter: 0,
    name: 'World'
}).render();