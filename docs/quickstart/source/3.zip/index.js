import {publish} from 'RAD.js'
import MainView from './source/views/main'

publish('navigation.show', {
    container: '#screen',
    content: MainView
});