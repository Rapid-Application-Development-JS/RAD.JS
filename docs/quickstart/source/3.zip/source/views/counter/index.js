import {View, template} from 'RAD.js';

class Counter extends View {

    template = template('<button>Clicks:<%= this.props.get("amount") %></button>');

    events = {
        'click button': 'click'
    };

    click() {
        let amount = this.props.get('amount');
        this.props.set('amount', amount + 1);
    }
}

module.exports = Counter;