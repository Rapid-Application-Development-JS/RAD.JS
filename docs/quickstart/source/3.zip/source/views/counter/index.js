import {View} from 'RAD.js';

class Counter extends View {
    template = require('./template.ejs');

    events = {
        'click button': 'onClick'
    };

    onClick() {
        let count = this.props.get('count');
        this.props.set('count', count + 1);
    }
}

module.exports = Counter;