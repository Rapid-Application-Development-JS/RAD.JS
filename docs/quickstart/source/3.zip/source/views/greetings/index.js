import {View} from 'RAD.js';

class Greetings extends View {
    template = require('./template.ejs');

    events = {
        'input input': 'nameChange'
    };
    
    getTemplateData(){
        return this.props.toJSON();
    }

    nameChange() {
        let name = this.refs.my_input.value;
        this.props.set('name', name);
    }
}

module.exports = Greetings;