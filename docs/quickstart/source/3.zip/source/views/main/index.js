import {View} from 'RAD.js';

class Main extends View {
    template = require('./template.ejs');
}

export default Main