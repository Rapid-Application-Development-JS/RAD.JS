import {View} from 'RAD.js';

export default class Main extends View {
    template = require('./template.ejs');
}