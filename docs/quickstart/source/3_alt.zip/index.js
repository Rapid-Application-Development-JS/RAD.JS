import {View, publish, template} from 'RAD.js'

class Counter extends View {
    template = template(`<button>Clicks:<%= this.data.count %></button>`);

    events = {
        'click button': 'onClick'
    };

    initialize(options) {
        this.data = options.data;
    }

    onClick() {
        this.data.count += 1;
        this.render();
    }
}

class Greetings extends View {
    template = template(`
        <h1><%= 'Hello, ' + this.data.name + '!' %></h1>
        <div>
            <input type="text" value="<%= this.data.name %>"/>
        </div>`);

    events = {
        'input input': 'onInput'
    };

    initialize(options) {
        this.data = options.data;
    }

    onInput(e) {
        this.data.name = e.target.value;
        this.render();
    }
}

class WelcomePage extends View {
    template = template(`
        <::this.components.Greetings data="<%= this.data %>" />
        <::this.components.Counter data="<%= this.data %>" />`);

    components = {
        Greetings: Greetings,
        Counter: Counter
    };

    data = {
        name: 'World',
        count: 0
    };
}

new WelcomePage({el: '#screen'}).render();