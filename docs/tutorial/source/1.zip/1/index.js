"use strict";
import {publish} from 'RAD.js'
import MainScreen from './source/views/main'

publish('navigation.show', {
    container: '#screen',
    content: MainScreen
});