import {Collection} from 'Backbone'
import Car from './car'

class Cars extends Collection {
    model = Car;
}

export default Cars