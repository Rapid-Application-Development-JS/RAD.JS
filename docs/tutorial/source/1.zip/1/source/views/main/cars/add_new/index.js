import {View} from 'RAD.js'

class AddNewView extends View {
    template = require('./template.ejs');
}

export default AddNewView