import {View} from 'RAD.js'

class CarsView extends View {
    template = require('./template.ejs');
}

export default CarsView