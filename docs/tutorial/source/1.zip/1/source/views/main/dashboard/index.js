
import {View} from 'RAD.js'

class DashboardView extends View {
    template = require('./template.ejs');
}

export default DashboardView