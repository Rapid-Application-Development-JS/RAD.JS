let templateFn = require('./template.ejs');

function menu(data, content) {
    let refs = templateFn(data, content);
}

export default menu;