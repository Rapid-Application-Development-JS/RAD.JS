import {Model} from 'Backbone'

class Car extends Model {
    
}

export default Car