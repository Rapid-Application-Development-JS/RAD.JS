"use strict";
import {publish} from 'RAD.js'
import MainScreen from './source/views/main'

publish('navigation.show', {
    container: '#screen',
    content: MainScreen
});

/* load css styles via webpack */
require('./node_modules/bootstrap/dist/css/bootstrap.min.css');
require('./source/assets/css/styles.css');