import {View} from 'RAD.js'

class DetailsView extends View {
    template = require('./template.ejs');
}

export default DetailsView