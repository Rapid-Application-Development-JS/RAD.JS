import {View} from 'RAD.js'

class MainView extends View {
    template = require('./template.ejs');
}

export default MainView